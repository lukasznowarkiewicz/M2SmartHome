DFU File Update Utility 
  -Files associated with changing the VID/PID of .dfu firmware upgrade files
Docs
  -Firmware Revision History
  -DFU Utility User Guide
  -PLDU User Guide
  -Benchmark and Media Compatibility Report
  -SQA Test Suite
  -USBDM User Guide
Firmware Object Code
  -Firmware
  -DFU Firmware Upgrade File
  -Dummy DFU Firmware Upgrade File (With fw version 999)
KillReg Utility
  -Killreg.exe for removing registry entries and stopping the seticon process
USB Drive Manager
  -Latest version of USB Drive Manager for DFU/Descriptor Update of the external nvstore data